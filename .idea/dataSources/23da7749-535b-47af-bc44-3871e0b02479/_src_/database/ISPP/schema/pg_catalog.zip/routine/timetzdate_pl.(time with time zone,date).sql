CREATE FUNCTION timetzdate_pl (time with time zone, date) RETURNS timestamp with time zone
	LANGUAGE sql
AS $$
select ($2 + $1)
$$
